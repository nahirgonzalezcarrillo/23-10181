#include <vector>

using namespace std;

int main(){
  return 0;
}

double mean(vector<double> v){
  double suma = 0;
  for (int i = 0; i < v.size(); i++){
    suma += v[i];
  }
  return sum / v.size();
}

double variance(vector<double> v){
  double suma_diferencias = 0;
  double promedio = mean(v);
  for (int i = 0; i < v.size(); i++) {
    suma_diferencias += pow(v[i] - promedio, 2);
  }
  return suma_diferencias / v.size();
}
  

double pearson_r(vector<double> A, vector<double> B){
  double sumaA = 0, sumaB = 0;{
      for (int i = 0; i < A.size(); i++){
          sumaA += A[i];
          sumaB += B[i];
      }
    double promedioA = sumaA / A.size();
    double promedioB = sumaB / B.size();
    double numerador = 0;
    double denominadorA = 0;
    double denominadorB = 0;
    for (int i = 0; i < A.size(); i++)
      numerador += (A[i] - promedioA) * (B[i] - promedioB);
      denominadorA += pow(A[i] - promedioA, 2); 
      denominadorB += pow(B[i] - promedioB, 2);
  }
  return numerador / sqrt(denominadorA * denominadorB);
}

vector<char> dec_to_septapus(int n) {
  return dec_a_base(n, 7);
}

vector<char> dec_to_octopus(int n) {
  return dec_a_base(n, 8);
}

vector<char> dec_to_hexakaidecapus(int n) {
  return dec_a_base(n, 16);
}

vector<char> septapus_to_dec(vector<char> s) {
  int decimal = base_a_dec_int(s, 7);
  return int_a_vector_dec(decimal);
}

vector<char> octopus_to_dec(vector<char> s) {
  int decimal = base_a_dec_int(s, 8);
  return int_a_vector_dec(decimal);
}

vector<char> hexakaidecapus_to_dec(vector<char> s) {
  int decimal = base_a_dec_int(s, 16);
  return int_a_vector_dec(decimal);
}

vector<char> septapus_to_octopus(vector<char> s) {
  int dec = base_a_dec_int(s, 7);
  return dec_to_octopus(dec);
}

vector<char> septapus_to_hexakaidecapus(vector<char> s) {
  int dec = base_a_dec_int(s, 7);
  return dec_to_hexakaidecapus(dec);
}

vector<char> octapus_to_septapus(vector<char> s) { 
  int dec = base_a_dec_int(s, 8);
  return dec_to_septapus(dec);
}

vector<char> octopus_to_hexakaidecapus(vector<char> s) {
  int dec = base_a_dec_int(s, 8);
  return dec_to_hexakaidecapus(dec);
}

vector<char> hexakaidecapus_to_septapus(vector<char> s) {
  int dec = base_a_dec_int(s, 16);
  return dec_to_septapus(dec);
}

vector<char> hexakaidecapus_to_octopus(vector<char> s) {
  int dec = base_a_dec_int(s, 16);
  return dec_to_octopus(dec);
}

//Cualquier valor numerico (0-15) a su caracter correspondiente (0-9, A-F)
char valor_a_char(int valor) {
  if (valor >= 0 && valor <= 9) {
    return '0' + valor;
  } else {
     return 'A' + (valor - 10);
  }
}
//Cualquier caracter (0-9, A-F) a su valor numerico (0-15)
int char_a_valor(char c) {
  if (c >= '0' && c <= '9') {
    return c - '0';
  } else if (c >= 'A' && c <= 'F') {
    return 10 + (c - 'A');
  } else if (c >= 'a' && c <= 'f') {
    return 10 + (c - 'a');
  }
  return 0;
}
//funcion para convertir de decimal a cualquier base
vector<char> dec_to_base(int n, int base){
  if (n == 0) {
    return {'0'};
  }
     vector<char> resultado;
     while (n > 0) {
       int residuo = n % base;
       resultado.push_back(valor_a_char(residuo));
       n /= base;
     }
  reverse(resultado.begin(), resultado.end());
  return resultado;
}

//funcion generica para converitr de cualquier base a decimal
int base_to_dec(vector<char> s, int base) {
  int resultado = 0;
  for ( char c : s) {
    resultado = resultado * base + char_a_valor(c);
  }
  return resultado;
}