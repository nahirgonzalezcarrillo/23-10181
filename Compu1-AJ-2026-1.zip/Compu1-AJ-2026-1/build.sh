#!/usr/bin/env bash
set -e

GLIBC=$(dirname $(ldd $(which ls) | grep 'libc.so' | awk '{print $3}') 2>/dev/null || echo "")
LIBGCC=$(ls /nix/store/*-gcc-14*-libgcc/lib/libgcc_s.so.1 2>/dev/null | xargs -I{} sh -c 'file {} | grep -q x86-64 && echo {}' | head -1 | xargs dirname 2>/dev/null || echo "")

EXTRA_FLAGS=""
[ -n "$GLIBC" ] && EXTRA_FLAGS="$EXTRA_FLAGS -B$GLIBC -L$GLIBC"
[ -n "$LIBGCC" ] && EXTRA_FLAGS="$EXTRA_FLAGS -L$LIBGCC"

echo "Building Tarea1/ex.cxx..."
g++ Tarea1/ex.cxx -o Tarea1/ex $EXTRA_FLAGS
echo "Build successful!"
echo "Running..."
./Tarea1/ex
